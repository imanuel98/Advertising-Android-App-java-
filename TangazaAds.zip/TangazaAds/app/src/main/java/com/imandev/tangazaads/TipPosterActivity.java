package com.imandev.tangazaads;

import android.Manifest;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class TipPosterActivity extends AppCompatActivity {
    private Button sendBtn;
    private String adPostId,adImageUri,adTitle,adPosterNo;
    private ImageView adPic;
    private TextView advertTitle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tip_poster);

        sendBtn =  findViewById(R.id.btnSendSMS);
        adPic = findViewById(R.id.ad_pic);
        advertTitle = findViewById(R.id.ad_title);

        adPostId = getIntent().getStringExtra("post_id");
        adImageUri = getIntent().getStringExtra("image_url");
        adTitle = getIntent().getStringExtra("ad_title");
        adPosterNo = getIntent().getStringExtra("poster_number");

        //view casting
        advertTitle.setText(adTitle);
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.placeholder);


        Glide.with(this)
                .applyDefaultRequestOptions(requestOptions)
                .load(adImageUri).into(adPic);

        sendBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String phoneNo = adPosterNo;
                String sms = "Hello, I am interested in your advert about "
                        +adTitle +"." +"Please reach out\n "
                        +"Tangaza Ads Platform";

                ActivityCompat.requestPermissions(TipPosterActivity.this, new String[]{Manifest.permission.SEND_SMS}, 1);


                if(TextUtils.isDigitsOnly(phoneNo)) {

                    try {
                        SmsManager smsManager = SmsManager.getDefault();
                        smsManager.sendTextMessage(phoneNo, null, sms, null, null);
                        Toast.makeText(TipPosterActivity.this, "message send successfully " + phoneNo, Toast.LENGTH_LONG).show();
                    } catch (Exception e) {
                        Toast.makeText(TipPosterActivity.this, "SMS Failed!" + e, Toast.LENGTH_SHORT).show();
                        e.printStackTrace();
                    }

                } else {
                    Toast.makeText(TipPosterActivity.this,"please enter a valid number in 07xxxxx.. format",Toast.LENGTH_LONG).show();
                }


            }
        });
    }

}

