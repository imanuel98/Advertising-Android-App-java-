package com.imandev.tangazaads.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.firestore.FirebaseFirestore;
import com.imandev.tangazaads.CategoryDetailActivity;
import com.imandev.tangazaads.R;
import com.imandev.tangazaads.models.category;

import java.util.List;

public class categoryRecyclerAdapter extends RecyclerView.Adapter<categoryRecyclerAdapter.viewHolder> {

    public List<category> cat_list;
    public Context mcontext;

    public categoryRecyclerAdapter(List<category> cat_list) {
        this.cat_list = cat_list;
    }

    @NonNull
    @Override
    public categoryRecyclerAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.category_item, parent, false);


        mcontext = parent.getContext();
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull categoryRecyclerAdapter.viewHolder holder, int position) {

        holder.setIsRecyclable(false);

        final String cTitle = cat_list.get(position).getTitle();
        holder.setTitle(cTitle);
        final String cDescription = cat_list.get(position).getDescription();
        holder.setDesc(cDescription);

        final String cImgLink = cat_list.get(position).getImage_url();
        holder.setcatImage(cImgLink);
        final String cThumbLink = cat_list.get(position).getImage_thumb();

        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(mcontext, CategoryDetailActivity.class);
                intent.putExtra("cat_title", cTitle);
                intent.putExtra("cat_desc",cDescription);
                mcontext.startActivity(intent);

            }
        });

    }

    @Override
    public int getItemCount() {
        return this.cat_list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {

        private View mView;
        private ImageView catImage;
        private TextView catTitle;
        private TextView catDesc;
        private LinearLayout linearLayout;

        public viewHolder(@NonNull View itemView) {
            super(itemView);

            mView = itemView;
            linearLayout = mView.findViewById(R.id.linear_cat);

        }

        public void setcatImage(String cImgLink) {

            catImage = mView.findViewById(R.id.category_icon);
            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.placeholder);


            //Glide.with(latContext).applyDefaultRequestOptions(requestOptions).load(downloadUri).into(adImageView);

            Glide.with(mcontext)

                    .applyDefaultRequestOptions(requestOptions)

                    .load(cImgLink)
                    .into(catImage);


        }

        public void setDesc(String cDescription) {
            catDesc = mView.findViewById(R.id.category_desc);
            catDesc.setText(cDescription);

        }

        public void setTitle(String cTitle) {
            catTitle = mView.findViewById(R.id.category_title);
            catTitle.setText(cTitle);
        }
    }
}
