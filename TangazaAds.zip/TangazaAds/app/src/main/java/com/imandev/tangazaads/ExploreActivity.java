package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.imandev.tangazaads.fragment.AccountFragment;
import com.imandev.tangazaads.fragment.HomeFragment;
import com.imandev.tangazaads.fragment.MessageFragment;

import de.hdodenhof.circleimageview.CircleImageView;

public class ExploreActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private FirebaseFirestore firebaseFirestore;
    private Animation smalltobig;
    private RelativeLayout mainTopRelative;

    private String current_user_id;
    private ImageView profilePic;

    private FloatingActionButton addPostBtn;
    private BottomNavigationView mainbottomNav;
    private BottomNavigationView mainTopNav;
    private CircleImageView aboutApp;
    private HomeFragment homeFragment;
    private AccountFragment accountFragment;
    private MessageFragment messageFragment;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_explore);

        mAuth = FirebaseAuth.getInstance();

        if(mAuth.getCurrentUser() != null){
            current_user_id = mAuth.getCurrentUser().getUid();
        }

        firebaseFirestore = FirebaseFirestore.getInstance();


        if(!isConnected(ExploreActivity.this)) buildDialog(ExploreActivity.this).show();

        //mainToolbar = (Toolbar) findViewById(R.id.main_toolbar);
        //setSupportActionBar(mainToolbar);
        //getSupportActionBar().setTitle("Tangaza Ads");

        if(mAuth.getCurrentUser() != null) {


            mainbottomNav = findViewById(R.id.mainBottomNav);
            aboutApp = findViewById(R.id.aboutbtn);
            //smalltobig = AnimationUtils.loadAnimation(this,R.anim.smalltobig);

            // FRAGMENTS
            homeFragment = new HomeFragment();

            accountFragment = new AccountFragment();
            messageFragment = new MessageFragment();


            initializeFragment();



            aboutApp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Intent about  = new Intent(ExploreActivity.this, AboutAppActivity.class);
                    startActivity(about);
                }
            });

            mainbottomNav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
                @SuppressLint("RestrictedApi")
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem item) {

                    Fragment currentFragment = getSupportFragmentManager().findFragmentById(R.id.main_container);

                    switch (item.getItemId()) {



                        case R.id.bottom_action_home:

                            replaceFragment(homeFragment, currentFragment);


                            return true;

                        case R.id.bottom_action_account:

                            replaceFragment(accountFragment, currentFragment);

                            return true;



                        case R.id.bottom_menu:

                            replaceFragment(messageFragment, currentFragment);

                            return true;

                        default:
                            return false;


                    }

                }
            });



            FirebaseUser current_user = FirebaseAuth.getInstance().getCurrentUser();

            if (current_user != null && current_user.isEmailVerified()) {

                firebaseFirestore.collection("Users").document(current_user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                        if (task.isSuccessful()) {

                            //String userName = task.getResult().getString("name");
                            String userImage = task.getResult().getString("image_url");
                            setUserData(userImage);


                        } else {
                            //Firebase Exception


                        }


                    }
                });

            }

        }

    }

    public void setUserData( String image){

        profilePic = findViewById(R.id.profile_image);



        RequestOptions placeholderOption = new RequestOptions();
        placeholderOption.placeholder(R.drawable.placeholder);

        Glide.with(this)
                .applyDefaultRequestOptions(placeholderOption)

                .load(image)
                .placeholder(R.drawable.placeholder)
                .centerCrop()
                .into(profilePic);

    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();


        if (currentUser == null) {

            sendToLogin();

        } else {


            if (!currentUser.isEmailVerified()) {
                String eMail = currentUser.getEmail();
                Toast.makeText(ExploreActivity.this,"Please Verify Email",Toast.LENGTH_LONG).show();

                //Intent verifyIntent = new Intent(ExploreActivity.this, VerificationActivity.class);
                //verifyIntent.putExtra("mail", eMail);
               // startActivity(verifyIntent);
                //finish();


            } else {


                //current_user_id = mAuth.getCurrentUser().getUid();

                firebaseFirestore.collection("Users").document(current_user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                        if (task.isSuccessful()) {

                            if (!task.getResult().exists()) {

                                Intent setupIntent = new Intent(ExploreActivity.this, SetupActivity.class);
                                startActivity(setupIntent);
                                finish();

                            }

                        } else {
                            String errorMessage = task.getException().getMessage();
                            Toast.makeText(ExploreActivity.this, "Error : " + errorMessage, Toast.LENGTH_LONG).show();
                        }

                    }
                });

            }

        }
    }

            private void logOut() {
                mAuth.signOut();
                sendToLogin();
            }

            private void sendToLogin() {

                Intent loginIntent = new Intent(ExploreActivity.this, LoginActivity.class);
                startActivity(loginIntent);
                finish();

            }

            private void initializeFragment(){

                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

                fragmentTransaction.add(R.id.main_container, homeFragment);

                fragmentTransaction.add(R.id.main_container, accountFragment);
                fragmentTransaction.add(R.id.main_container, messageFragment);



                fragmentTransaction.hide(accountFragment);
                fragmentTransaction.hide(messageFragment);
                fragmentTransaction.hide(homeFragment);


                fragmentTransaction.commit();

            }

            private void replaceFragment(Fragment fragment, Fragment currentFragment){

                FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
                if(fragment == homeFragment){


                    fragmentTransaction.hide(accountFragment);
                    fragmentTransaction.hide(messageFragment);


                }

                if(fragment == accountFragment){

                    fragmentTransaction.hide(homeFragment);

                    fragmentTransaction.hide(messageFragment);


                }



                if(fragment == messageFragment){

                    fragmentTransaction.hide(homeFragment);
                    fragmentTransaction.hide(accountFragment);


                }


                fragmentTransaction.show(fragment);

                //fragmentTransaction.replace(R.id.main_container, fragment);
                fragmentTransaction.commit();

            }

            public boolean isConnected(Context context) {

                ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
                NetworkInfo netinfo = cm.getActiveNetworkInfo();

                if (netinfo != null && netinfo.isConnectedOrConnecting()) {
                    android.net.NetworkInfo wifi = cm.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
                    android.net.NetworkInfo mobile = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);

                    if((mobile != null && mobile.isConnectedOrConnecting()) || (wifi != null && wifi.isConnectedOrConnecting())) return true;
                    else return false;
                } else
                    return false;
            }

            public AlertDialog.Builder buildDialog(Context c) {

                AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setTitle("No Internet Connection");
                builder.setMessage("You need to have Mobile Data or wifi to access this. Press ok to Exit");
                builder.setCancelable(false);

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        finish();
                    }
                });

                return builder;
            }

            public androidx.appcompat.app.AlertDialog.Builder logoutBuildDialog(Context c) {

                androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(c);
                builder.setTitle("Confirm Log out");
                //builder.setMessage("You need to have Mobile Data or wifi to access this. Press ok to Exit");
                builder.setCancelable(true);

                builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        logOut();

                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(ExploreActivity.this, " Keep Advertising" , Toast.LENGTH_SHORT).show();
                    }
                });

                return builder;
            }




}