package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPasswordActivity extends AppCompatActivity {

    private Button Reset;
    private TextView SignUpTV;
    private TextView Login;
    private AutoCompleteTextView resetMail;
    private FirebaseAuth mAuth;
    private ProgressDialog mForgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mAuth = FirebaseAuth.getInstance();

        Login = findViewById(R.id.Rempass);
        Reset = findViewById(R.id.reset_btn);
        SignUpTV = findViewById(R.id.btnSignup);
        resetMail = findViewById(R.id.resetemail);
        mForgot = new ProgressDialog(this);

        Reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = resetMail.getText().toString();

                if (email.equals("")){

                    Toast.makeText(ForgotPasswordActivity.this, "Mail filed is required!", Toast.LENGTH_LONG).show();

                }else {

                    mForgot.setTitle("Retrieving Password");
                    mForgot.setMessage("Sending Link to Email");
                    mForgot.setCanceledOnTouchOutside(false);
                    mForgot.show();

                    mAuth.sendPasswordResetEmail(email).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {
                            if (task.isSuccessful()){
                                Toast.makeText(ForgotPasswordActivity.this, "Please check your Email", Toast.LENGTH_LONG).show();
                                startActivity(new Intent(ForgotPasswordActivity.this, LoginActivity.class));
                            }else {
                                String error = task.getException().getMessage();
                                Toast.makeText(ForgotPasswordActivity.this, error, Toast.LENGTH_SHORT).show();
                            }

                            mForgot.dismiss();
                        }
                    });
                }
            }
        });


        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent logIntent = new Intent(ForgotPasswordActivity.this, LoginActivity.class);
                startActivity(logIntent);
                finish();
            }
        });


        SignUpTV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent regIntent = new Intent(ForgotPasswordActivity.this, SignupActivity.class);
                startActivity(regIntent);
                finish();
            }
        });

    }
}