package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import id.zelory.compressor.Compressor;

public class AddServiceAd extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private ImageView newPostImage;
    private ImageView extraImage1,extraImage2;
    private TextInputEditText newPostDesc,adDescription,adLocation,adContact;
    private ImageButton newPostBtn;


    private ProgressDialog mNewPost;

    private Uri postImageUri = null;
    // private Uri extraImage1Uri = null;
    //private Uri extraImage2Uri = null;

    private StorageReference storageReference;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;

    private String current_user_id;
    private Bitmap compressedImageFile;

    private Spinner spinner;
    private  ImageButton backbtn;

    private String textSpinnner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_service_ad);

        storageReference = FirebaseStorage.getInstance().getReference();
        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();


        newPostImage = findViewById(R.id.new_post_image);

        newPostDesc = findViewById(R.id.new_post_desc);
        adDescription = findViewById(R.id.ad_description);
        adContact = findViewById(R.id.ad_contact);
        adLocation = findViewById(R.id.ad_location);
        newPostBtn = findViewById(R.id.post_btn);
        backbtn = findViewById(R.id.bt_close);


        backbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onBackPressed();
            }
        });

        mNewPost = new ProgressDialog(this);

        spinner = findViewById(R.id.spinner);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.business_category,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);

        newPostImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                CropImage.activity()
                        .setGuidelines(CropImageView.Guidelines.ON)
                        .setMinCropResultSize(720, 720)
                        //.setAspectRatio(1, 1)
                        .start(AddServiceAd.this);


            }
        });


        newPostBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String desc = newPostDesc.getText().toString();
                final String details = adDescription.getText().toString();
                final String location = adLocation.getText().toString();
                final String contact = adContact.getText().toString();
                final String pricetype = textSpinnner;



                if (!TextUtils.isEmpty(desc) && postImageUri != null && !TextUtils.isEmpty(details) && !TextUtils.isEmpty(location)
                        && !TextUtils.isEmpty(contact)){

                    mNewPost.setTitle("Posting");
                    mNewPost.setMessage("Uploading Advert...");
                    mNewPost.setCanceledOnTouchOutside(false);
                    mNewPost.show();

                    final String randomName = UUID.randomUUID().toString();

                    // PHOTO UPLOAD
                    File newImageFile = new File(postImageUri.getPath());
                    try {

                        compressedImageFile = new Compressor(AddServiceAd.this)
                                .setMaxHeight(720)
                                .setMaxWidth(720)
                                .setQuality(50)
                                .compressToBitmap(newImageFile);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    compressedImageFile.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                    byte[] imageData = baos.toByteArray();




                    final StorageReference filePath = storageReference.child("services images").child(randomName +".jpg");


                    Task uploadAdTask = filePath.putBytes(imageData);

                    uploadAdTask.continueWithTask(new Continuation() {
                        @Override
                        public Object then(@NonNull Task task) throws Exception {

                            if (!task.isSuccessful()){

                                throw task.getException();

                            }

                            return filePath.getDownloadUrl();
                        }
                    })
                            .addOnCompleteListener(new OnCompleteListener() {
                                @Override
                                public void onComplete(@NonNull final Task task) {

                                    Uri download_Uri = (Uri) task.getResult();
                                    final String downloadUri = download_Uri.toString();

                                    if (task.isSuccessful()){

                                        File newThumbFile = new File(postImageUri.getPath());
                                        try {

                                            compressedImageFile = new Compressor(AddServiceAd.this)
                                                    .setMaxHeight(100)
                                                    .setMaxWidth(100)
                                                    .setQuality(1)
                                                    .compressToBitmap(newThumbFile);

                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }


                                        ByteArrayOutputStream baos = new ByteArrayOutputStream();
                                        compressedImageFile.compress(Bitmap.CompressFormat.JPEG, 100, baos);
                                        byte[] thumbData = baos.toByteArray();

                                        final StorageReference thumbpath = storageReference.child("services_images/thumbs").child(randomName + ".jpg");

                                        Task uploadThumbTask = thumbpath.putBytes(thumbData);

                                        uploadThumbTask.continueWithTask(new Continuation() {
                                            @Override
                                            public Object then(@NonNull Task task) throws Exception {

                                                if (!task.isSuccessful()){

                                                    throw task.getException();

                                                }

                                                return thumbpath.getDownloadUrl();
                                            }
                                        })
                                                .addOnCompleteListener(new OnCompleteListener() {
                                                    @Override
                                                    public void onComplete(@NonNull Task task) {



                                                        //.addOnSuccessListener(new OnSuccessListener() {
                                                        // @Override
                                                        //public void onSuccess(Object o) {

                                                        Uri thumbdownload_Uri = (Uri) task.getResult();
                                                        String downloadthumbUri = thumbdownload_Uri.toString();



                                                        Map<String, Object> postMap = new HashMap<>();
                                                        postMap.put("image_url", downloadUri);
                                                        postMap.put("image_thumb", downloadthumbUri);
                                                        postMap.put("desc", desc);
                                                        postMap.put("details", details);
                                                        postMap.put("location", location);
                                                        postMap.put("contact", contact);
                                                        postMap.put("adtype", pricetype);
                                                        postMap.put("user_id", current_user_id);
                                                        postMap.put("timestamp", FieldValue.serverTimestamp());


                                                        firebaseFirestore.collection("Services").add(postMap).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<DocumentReference> task) {

                                                                if (task.isSuccessful()){

                                                                    Toast.makeText(AddServiceAd.this, "Finalizing... ", Toast.LENGTH_LONG).show();
                                                                    //Intent mainIntent = new Intent(AddProductAd.this, MainActivity.class);
                                                                    //startActivity(mainIntent);
                                                                    //finish();

                                                                }else {


                                                                }

                                                                // mNewPost.dismiss();

                                                            }
                                                        });


                                                        firebaseFirestore.collection("Ads Pool").add(postMap).addOnCompleteListener(new OnCompleteListener<DocumentReference>() {
                                                            @Override
                                                            public void onComplete(@NonNull Task<DocumentReference> task) {

                                                                if (task.isSuccessful()){

                                                                    Toast.makeText(AddServiceAd.this, " Advert Added Successfully ", Toast.LENGTH_LONG).show();
                                                                    Intent mainIntent = new Intent(AddServiceAd.this, MainActivity.class);
                                                                    startActivity(mainIntent);
                                                                    finish();

                                                                }else {


                                                                }

                                                                mNewPost.dismiss();

                                                            }
                                                        });

                                                    }
                                                })

                                                .addOnFailureListener(new OnFailureListener() {
                                                    @Override
                                                    public void onFailure(@NonNull Exception e) {


                                                    }
                                                });







                                    }else {

                                        String error = task.getException().getMessage();
                                        Toast.makeText(AddServiceAd.this, "IMAGE    Error : " +error, Toast.LENGTH_LONG ).show();

                                        mNewPost.dismiss();

                                    }

                                }
                            });


                }

            }
        });

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        textSpinnner = parent.getItemAtPosition(position).toString();


        // Toast.makeText(parent.getContext(), textSpinnner, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onNothingSelected(AdapterView<?> parent) {


    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                postImageUri = result.getUri();
                //extraImage1Uri = result.getUri();
                //extraImage2Uri = result.getUri();

                newPostImage.setImageURI(postImageUri);
                // extraImage1.setImageURI(extraImage1Uri);
                //extraImage2.setImageURI(extraImage2Uri);

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }

    }

    @Override
    protected void onStart() {
        super.onStart();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();


        if (currentUser == null) {

            Toast.makeText(AddServiceAd.this,"You Have To be Logged in To Add an Advert",Toast.LENGTH_LONG).show();
            sendToLogin();

        } else {

            current_user_id = firebaseAuth.getCurrentUser().getUid();

            if (!currentUser.isEmailVerified()) {
                String eMail = currentUser.getEmail();
                Toast.makeText(AddServiceAd.this,"Please Verify Your Email to Add Post",Toast.LENGTH_LONG).show();

                //Intent verifyIntent = new Intent(ExploreActivity.this, VerificationActivity.class);
                //verifyIntent.putExtra("mail", eMail);
                //startActivity(verifyIntent);
                //finish();


            }
        }
    }

    private void sendToLogin() {

        Intent loginIntent = new Intent(AddServiceAd.this, LoginActivity.class);
        startActivity(loginIntent);
        finish();

    }

}
