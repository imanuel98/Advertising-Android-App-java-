package com.imandev.tangazaads;



import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.smarteist.autoimageslider.DefaultSliderView;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderLayout;
import com.smarteist.autoimageslider.SliderView;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdDetailActivity extends AppCompatActivity {

    private ImageView adImageView;
    private TextView descView;
    private TextView adTitle;
    private TextView advertContact;
    private TextView advertDetails;
    private TextView advertType;
    private TextView advertLocation;
    private TextView adDate;
    private TextView adUserName;
    private CircleImageView adUserImage;
    private ImageView blogLikeBtn;
    private TextView blogLikeCount;
    private TextView blogCommentCount;
    private Button Tip,call, message;
    private ImageView blogCommentBtn;
    private Context context;
    SliderLayout sliderLayout;
    private FirebaseUser user;


    String imageUrl,desc_data,adDetail,adContact,adLocation,adtype,adPostId,userPostId,currentUserId;

    private CircleImageView userImage;
    private TextView userName;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ad_detail);



        //blogLikeBtn = findViewById(R.id.blog_like_btn);
        //blogCommentBtn = findViewById(R.id.blog_comment_icon);
        //descView = findViewById(R.id.blog_desc);

        Tip = findViewById(R.id.tip);
        call = findViewById(R.id.call);
        adTitle = findViewById(R.id.detailed_title);
        advertContact = findViewById(R.id.ad_contact);
        advertDetails = findViewById(R.id.ad_description);
        advertLocation = findViewById(R.id.ad_location);
        advertType = findViewById(R.id.ad_type);
        message = findViewById(R.id.smessage);

        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        user = firebaseAuth.getCurrentUser();





        imageUrl = getIntent().getStringExtra("image_url");
        //String thumbUrl = getIntent().getStringExtra("thumb_url");

        desc_data = getIntent().getStringExtra("desc_text");
        adTitle.setText(desc_data);

        adDetail = getIntent().getStringExtra("ad_detail");
        advertDetails.setText(adDetail);

        adContact = getIntent().getStringExtra("ad_contact");
        advertContact.setText(adContact);

        adLocation = getIntent().getStringExtra("ad_location");
        advertLocation.setText(adLocation);

        adtype = getIntent().getStringExtra("ad_type");
        advertType.setText(adtype);
        adPostId = getIntent().getStringExtra("post_id");

        userPostId = getIntent().getStringExtra("user_id");

        if (currentUserId != null){
            currentUserId = firebaseAuth.getCurrentUser().getUid();


        }

        if (currentUserId != null && currentUserId.equals(userPostId)){
            hideCommunication();

        }



        getPosterData();
        //Slider Layout
        sliderLayout = findViewById(R.id.imageSlider);
        sliderLayout.setIndicatorAnimation(IndicatorAnimations.SWAP); //set indicator animation by using SliderLayout.Animations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        sliderLayout.setScrollTimeInSec(3); //set scroll delay in seconds :

        setSliderViews();

        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user != null){
                    Intent message = new Intent(AdDetailActivity.this, MessageActivity.class);
                    message.putExtra("user_id", userPostId);
                    startActivity(message);
                }else {
                    Toast.makeText(AdDetailActivity.this,"You Have to be logged in to Message users",Toast.LENGTH_LONG).show();
                    sendToLogin();
                }






            }
        });

        Tip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (user != null){
                    Intent i = new Intent(AdDetailActivity.this, TipPosterActivity.class);
                    i.putExtra("post_id", adPostId);
                    i.putExtra("image_url", imageUrl);
                    i.putExtra("ad_title", desc_data);
                    i.putExtra("poster_number", adContact);
                    startActivity(i);
                }else {
                    Toast.makeText(AdDetailActivity.this,"You Have to be logged in to Tip users",Toast.LENGTH_LONG).show();
                    sendToLogin();
                }




            }
        });

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (user != null){
                    Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse("tel:" + adContact));
                    //callIntent.setData(Uri.parse(adContact));
                    if (ActivityCompat.checkSelfPermission(getApplicationContext(), Manifest.permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
                        Toast.makeText(getApplicationContext(),"Please Grant Permission",Toast.LENGTH_LONG).show();
                        requestPermission();
                    }else {
                        startActivity(callIntent);
                    }
                }else {
                    Toast.makeText(AdDetailActivity.this,"You Have to be logged in to Call users",Toast.LENGTH_LONG).show();
                    sendToLogin();
                }



            }
        });



    }

    private void sendToLogin() {
        Intent i = new Intent(AdDetailActivity.this,LoginActivity.class);
        startActivity(i);
    }

    private void hideCommunication() {

        message.setVisibility(View.INVISIBLE);
        Tip.setVisibility(View.INVISIBLE);
        call.setVisibility(View.INVISIBLE);
    }

    private void requestPermission() {
        ActivityCompat.requestPermissions(AdDetailActivity.this,new String[]{Manifest.permission.CALL_PHONE},1);
    }

    public void getPosterData(){
        //User Data retrieval
        firebaseFirestore.collection("Users").document(userPostId).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()) {

                    String userName = task.getResult().getString("name");
                    String userImage = task.getResult().getString("image_url");
                    setPosterData(userName,userImage);


                } else {
                    //Firebase Exception


                }


            }
        });
    }

    public void setPosterData(String userName, String userImage){

        this.userImage = findViewById(R.id.ad_post_userpic);
        this.userName = findViewById(R.id.ad_post_username);

        this.userName.setText(userName);

        RequestOptions placeholderOption = new RequestOptions();
        placeholderOption.placeholder(R.drawable.profile_placeholder);

        Glide.with(this)
                .applyDefaultRequestOptions(placeholderOption)

                .load(userImage)
                // .placeholder(R.drawable.profile_placeholder)
                .centerCrop()
                .into(this.userImage);



    }


    private void setSliderViews() {

        for (int i = 0; i <= 3; i++) {

            DefaultSliderView sliderView = new DefaultSliderView(this);

            switch (i) {
                case 0:
                    sliderView.setImageUrl(imageUrl);
                    break;
                case 1:
                    sliderView.setImageUrl(imageUrl);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/218983/pexels-photo-218983.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
                case 2:
                    sliderView.setImageUrl(imageUrl);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/747964/pexels-photo-747964.jpeg?auto=compress&cs=tinysrgb&h=750&w=1260");
                    break;
                case 3:
                    sliderView.setImageUrl(imageUrl);
                    //sliderView.setImageUrl("https://images.pexels.com/photos/929778/pexels-photo-929778.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260");
                    break;
            }

            sliderView.setImageScaleType(ImageView.ScaleType.CENTER_CROP);
            sliderView.setDescription(desc_data);

            sliderView.setOnSliderClickListener(new SliderView.OnSliderClickListener() {
                @Override
                public void onSliderClick(SliderView sliderView) {
                    Toast.makeText(AdDetailActivity.this, " " + (desc_data), Toast.LENGTH_SHORT).show();
                    Toast.makeText(AdDetailActivity.this, " This ad is of type" + (adtype), Toast.LENGTH_SHORT).show();
                }
            });

            //at last add this view in your layout :
            sliderLayout.addSliderView(sliderView);
        }

    }


    @Override
    protected void onStart() {
        super.onStart();


        if (user != null) {
            currentUserId = firebaseAuth.getCurrentUser().getUid();
        }

        if (currentUserId != null){
            hideCommunication();
        }
    }
}
