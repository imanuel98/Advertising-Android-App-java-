package com.imandev.tangazaads.models;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.Exclude;

public class AdPostId {

    @Exclude
    public String BlogPostId;

    public <T extends AdPostId> T withId(@NonNull final String id) {
        this.BlogPostId = id;
        return (T) this;
    }

}