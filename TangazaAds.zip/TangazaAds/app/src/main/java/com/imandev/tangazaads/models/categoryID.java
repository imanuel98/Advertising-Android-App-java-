package com.imandev.tangazaads.models;

import androidx.annotation.NonNull;

import com.google.firebase.firestore.Exclude;

public class categoryID {

    @Exclude
    public String catId;

    public <T extends categoryID> T withId(@NonNull final String id) {
        this.catId = id;
        return (T) this;
    }

}
