package com.imandev.tangazaads;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.imandev.tangazaads.adapters.AdvertRecyclerAdapter;
import com.imandev.tangazaads.adapters.MyAdsAdapter;
import com.imandev.tangazaads.models.AdPost;
;

import java.util.ArrayList;
import java.util.List;

public class MyPostsActivity extends AppCompatActivity {

    private RecyclerView myAdsManageList;
    private List<AdPost> advet_list;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;
    private MyAdsAdapter myAdsAdapter;

    private String user_id;
    private String current_user_id;

    private TextView myUsername;
    private ImageView myProfilepic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_posts);

        //initialization
        advet_list = new ArrayList<>();
        myAdsManageList = findViewById(R.id.user_manage_ads);

        //myAdvertsAdapter = new MyAdvertsAdapter(advet_list);
        myAdsAdapter = new MyAdsAdapter(advet_list);
        firebaseAuth = FirebaseAuth.getInstance();
        current_user_id = firebaseAuth.getCurrentUser().getUid();
        myAdsManageList.setLayoutManager(new LinearLayoutManager(MyPostsActivity.this));
        myAdsManageList.setAdapter(myAdsAdapter);

        user_id = getIntent().getStringExtra("user_id");
        if(firebaseAuth.getCurrentUser() != null) {

            firebaseFirestore = FirebaseFirestore.getInstance();

            //User Data retrieval
            firebaseFirestore.collection("Users").document(user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if (task.isSuccessful()){

                        String userName = task.getResult().getString("name");
                        String userImage = task.getResult().getString("image_url");
                        setUserData(userName, userImage);


                    }else{
                        //Firebase Exception


                    }



                }
            });

            Query firstQuery = firebaseFirestore.collection("Ads Pool")
                    .whereEqualTo("user_id", user_id)
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    // .limit(5)
                    ;

            firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                   /* if (isFirstPageFirstload){
                        lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
                        advet_list.clear();
                    }*/

                    if (queryDocumentSnapshots != null) {
                        for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {




                            if (doc.getType() == DocumentChange.Type.ADDED) {

                                String blogPostId = doc.getDocument().getId();

                                AdPost blogPost = doc.getDocument().toObject(AdPost.class).withId(blogPostId);

                                //if (isFirstPageFirstload){

                                advet_list.add(blogPost);
                                // }else {

                                //advet_list.add(0,blogPost);
                                //}
                               myAdsAdapter.notifyDataSetChanged();
                            }
                        }
                        // isFirstPageFirstload = false;
                    }
                }
            });
        }



    }

    private void setUserData(String userName, String userImage) {

        myUsername= findViewById(R.id.user_name);
        myProfilepic = findViewById(R.id.user_profile_pic);


        myUsername.setText(userName);

        RequestOptions placeholderOption = new RequestOptions();
        placeholderOption.placeholder(R.drawable.placeholder);

        Glide.with(this)
                .applyDefaultRequestOptions(placeholderOption)

                .load(userImage)
                // .placeholder(R.drawable.profile_placeholder)
                .centerCrop()
                .into(myProfilepic);

    }

    private void loadMorePosts() {
        Query nextQuery = firebaseFirestore.collection("Ads Pool")
                .whereEqualTo("user_id", current_user_id)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                //.startAfter(lastVisible)
                .limit(5);

        nextQuery.addSnapshotListener(MyPostsActivity.this, new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                assert queryDocumentSnapshots != null;
                if (!queryDocumentSnapshots.isEmpty()) {

                    //lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);

                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {

                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String blogPostId = doc.getDocument().getId();

                            AdPost blogPost = doc.getDocument().toObject(AdPost.class).withId(blogPostId);
                            advet_list.add(blogPost);

                            myAdsAdapter.notifyDataSetChanged();
                        }

                    }
                }

            }
        });


    }
}
