package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class VerificationActivity extends AppCompatActivity {

    private TextView mail,resend,backLogin;
    private Button verify,notNow;
    private FirebaseUser firebaseUser;
    private FirebaseAuth firebaseAuth;
    private ImageView verifiedTM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        mail = findViewById(R.id.appName);
        verify = findViewById(R.id.verifybtn);
        resend = findViewById(R.id.Resend);
        backLogin = findViewById(R.id.Login);
        notNow = findViewById(R.id.verifybtnNot);

        firebaseAuth = FirebaseAuth.getInstance();
        firebaseUser = firebaseAuth.getCurrentUser();


        String eMail = getIntent().getStringExtra("mail");
        mail.setText(eMail);

        backLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendToLogin();
            }
        });



        notNow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(VerificationActivity.this,MainActivity.class);
                startActivity(i);
                finish();
            }
        });
        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {

                        Toast.makeText(VerificationActivity.this, "Verification Email Successfully Send, Please check Mailbox",Toast.LENGTH_LONG).show();
                    }
                });

            }
        });

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firebaseAuth.signOut();
                sendToLogin();
                finish();

/*
                if (firebaseUser.isEmailVerified()){
                    Intent setupIntent = new Intent(VerificationActivity.this, SetupActivity.class);
                    startActivity(setupIntent);
                    finish();
                }else {
                    Toast.makeText(VerificationActivity.this, "Please Complete email Verification to Proceed",Toast.LENGTH_LONG).show();
                }

 */




            }
        });


    }

    private void sendToLogin() {

        firebaseAuth.signOut();
        Intent loginIntent = new Intent(VerificationActivity.this, LoginActivity.class);
        startActivity(loginIntent);
        finish();

    }
}
