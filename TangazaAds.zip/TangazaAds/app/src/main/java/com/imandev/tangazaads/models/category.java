package com.imandev.tangazaads.models;

import java.util.Date;

public class category extends categoryID  {

    public String  image_url, title, image_thumb, description;
    public Date timestamp;


    public category() {
    }

    public category(String image_url, String title, String image_thumb, String description, Date timestamp) {
        this.image_url = image_url;
        this.title = title;
        this.image_thumb = image_thumb;
        this.description = description;
        this.timestamp = timestamp;
    }

    public String getImage_url() {
        return image_url;
    }

    public void setImage_url(String image_url) {
        this.image_url = image_url;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getImage_thumb() {
        return image_thumb;
    }

    public void setImage_thumb(String image_thumb) {
        this.image_thumb = image_thumb;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Date timestamp) {
        this.timestamp = timestamp;
    }
}
