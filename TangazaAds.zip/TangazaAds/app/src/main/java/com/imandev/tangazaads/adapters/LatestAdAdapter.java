package com.imandev.tangazaads.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.imandev.tangazaads.AdDetailActivity;
import com.imandev.tangazaads.R;
import com.imandev.tangazaads.models.AdPost;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LatestAdAdapter extends RecyclerView.Adapter<LatestAdAdapter.viewHolder> {

    public List<AdPost> ad_list;
    public Context latContext;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;
    private String userPostId;
    private String currentUserId;


    public LatestAdAdapter(List<AdPost> ad_list){

        this.ad_list = ad_list;

    }

    @NonNull
    @Override
    public LatestAdAdapter.viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.latest_ad_view, parent, false);

        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        latContext = parent.getContext();
        return new LatestAdAdapter.viewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull LatestAdAdapter.viewHolder holder, int position) {

        holder.setIsRecyclable(false);

        final String postId = ad_list.get(position).BlogPostId;

        if (currentUserId != null){
            currentUserId = firebaseAuth.getCurrentUser().getUid();
        }



        final String desc_data = ad_list.get(position).getDesc();
        holder.setDescText(desc_data);

        final String adType = ad_list.get(position).getAdtype();
        holder.setAdType(adType);

        final String adDetail = ad_list.get(position).getDetails();
        final String adContact = ad_list.get(position).getContact();
        final String adLocation = ad_list.get(position).getLocation();
        final String user_id = ad_list.get(position).getUser_id();
        final String image_url = ad_list.get(position).getImage_url();
        final String thumbUri = ad_list.get(position).getImage_thumb();


        holder.setAdImage(image_url, thumbUri);

        holder.latestAdPic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                if (currentUserId != null){

                    //views
                    firebaseFirestore.collection("Ads Pool/" + postId + "/View").document(currentUserId).get()
                            .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                                @Override
                                public void onComplete(@NonNull Task<DocumentSnapshot> task) {


                                    if (!task.getResult().exists()){
                                        Map<String, Object> viewsMap = new HashMap<>();
                                        viewsMap.put("timestamp", FieldValue.serverTimestamp());
                                        firebaseFirestore.collection("Ads Pool/" + postId + "/View").document(currentUserId).set(viewsMap);

                                    }else {


                                    }

                                }
                            });





                }else {
                    Intent intent = new Intent(latContext, AdDetailActivity.class);
                    intent.putExtra("image_url", image_url);
                    //intent.putExtra("thumb_url", thumbUri );
                    intent.putExtra("post_id", postId);
                    intent.putExtra("desc_text", desc_data);
                    intent.putExtra("ad_detail", adDetail);
                    intent.putExtra("ad_contact", adContact);
                    intent.putExtra("ad_location", adLocation);
                    intent.putExtra("ad_type", adType);
                    intent.putExtra("user_id", user_id );

                    latContext.startActivity(intent);

                }




            }
        });

    }

    @Override
    public int getItemCount() {
        return ad_list.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {

        private View lView;
        private ImageView latestAdPic;
        private TextView latestAdTitle;
        private TextView latestAdType;


        public viewHolder(@NonNull View itemView) {
            super(itemView);

             lView = itemView;

        }

        public void setDescText( String descText){

            latestAdTitle= lView.findViewById(R.id.latest_ad_title);
            latestAdTitle.setText(descText);


        }

        public void setAdType( String adType){

            latestAdType = lView.findViewById(R.id.latest_ad_type);
            latestAdType.setText(adType);


        }

        @SuppressLint("CheckResult")
        public void setAdImage(String downloadUri, String thumbUri){

            latestAdPic = lView.findViewById(R.id.blog_image);

            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.placeholder);


            //Glide.with(latContext).applyDefaultRequestOptions(requestOptions).load(downloadUri).into(adImageView);

            Glide.with(latContext)

                    .applyDefaultRequestOptions(requestOptions)

                    .load(downloadUri).thumbnail(
                    Glide.with(latContext).load(thumbUri)
                    //.placeholder(R.drawable.image_placeholder)

            ).into(latestAdPic);



        }

    }
}
