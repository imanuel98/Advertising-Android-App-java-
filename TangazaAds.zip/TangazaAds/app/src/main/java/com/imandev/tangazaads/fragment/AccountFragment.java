package com.imandev.tangazaads.fragment;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.StorageReference;
import com.imandev.tangazaads.LoginActivity;
import com.imandev.tangazaads.MyPostsActivity;
import com.imandev.tangazaads.R;
import com.imandev.tangazaads.SetupActivity;


import de.hdodenhof.circleimageview.CircleImageView;


/**
 * A simple {@link Fragment} subclass.
 */
public class AccountFragment extends Fragment {

    private Button updateAccount, logOut;
    private CircleImageView profilePic;
    private TextView userName,userNameTV,userMobile,userMail,userAddress,userBio;
    private TextView adsManagebtn;

    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;
    private String user_id;
    private StorageReference storageReference;
    private Uri mainImageURI = null;
    private Context context;

    public AccountFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, final ViewGroup container,
                             Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragment_account, container, false);
        // Inflate the layout for this fragment


        //Views Initialization
        updateAccount = view.findViewById(R.id.updt_btn);
        adsManagebtn = view.findViewById(R.id.manage_ads);
        userName = view.findViewById(R.id.user_name);
        userNameTV = view.findViewById(R.id.user_nameTV);
        userMobile = view.findViewById(R.id.user_mobile);
        userAddress = view.findViewById(R.id.user_address);
        userMail = view.findViewById(R.id.user_email);
        userBio = view.findViewById(R.id.user_Bio);
        profilePic = view.findViewById(R.id.user_profile_pic);
        logOut = view.findViewById(R.id.logout_btn);

        context = view.getContext();

        firebaseAuth = FirebaseAuth.getInstance();
        user_id = firebaseAuth.getCurrentUser().getUid();


        if(firebaseAuth.getCurrentUser() != null ) {


           // && firebaseAuth.getCurrentUser().isEmailVerified()

            firebaseFirestore = FirebaseFirestore.getInstance();


            firebaseFirestore.collection("Users").document(user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @SuppressLint("CheckResult")
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                    if (task.isSuccessful()){

                        if (task.getResult().exists()){

                            String name = task.getResult().getString("name");
                            String image = task.getResult().getString("image_url");
                            String phone = task.getResult().getString("phone");
                            String location = task.getResult().getString("location");
                            String bio = task.getResult().getString("about");
                            String email = firebaseAuth.getCurrentUser().getEmail();

                            mainImageURI = Uri.parse(image);
                            userName.setText(name);
                            userNameTV.setText(name);
                            userMobile.setText(phone);
                            userAddress.setText(location);
                            userBio.setText(bio);
                            userMail.setText(email);

                            RequestOptions placeholderRequest = new RequestOptions();
                            placeholderRequest.placeholder(R.drawable.default_image);


                            Glide.with(view.getContext()).setDefaultRequestOptions(placeholderRequest).load(image).into(profilePic);


                        }
                    }else {

                        String error = task.getException().getMessage();
                        Toast.makeText(view.getContext(), "FIRESTORE Retrieve Error : " +error, Toast.LENGTH_LONG ).show();

                    }


                }
            });



            adsManagebtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   Intent home = new Intent(view.getContext(), MyPostsActivity.class);
                    home.putExtra("user_id", user_id);
                    startActivity(home);

                }
            });

            updateAccount.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent setupIntent = new Intent(view.getContext(), SetupActivity.class);
                    startActivity(setupIntent);
                }
            });

            logOut.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    logoutBuildDialog(context).show();
                }
            });

        }




        return view;
    }

    private AlertDialog.Builder logoutBuildDialog(final Context context) {

        androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle("Confirm Log out");
        //builder.setMessage("You need to have Mobile Data or wifi to access this. Press ok to Exit");
        builder.setCancelable(true);

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                firebaseAuth.signOut();
                Intent logout = new Intent(context, LoginActivity.class);
                startActivity(logout);
                //finish();

            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(context, " Keep Advertising" , Toast.LENGTH_SHORT).show();
            }
        });

        return builder;
    }


}
