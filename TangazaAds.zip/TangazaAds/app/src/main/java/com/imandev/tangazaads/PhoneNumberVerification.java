package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

import static android.content.ContentValues.TAG;

public class PhoneNumberVerification extends AppCompatActivity {

    public static final int TIMEOUT_DURATION = 60;
    private Button resend;
    private Button verify;
    private EditText code;
    private TextView title;
    private TextView msg;
    private String phoneNumber;
    private boolean mVerificationInProgress = false;
    private String mVerificationId;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallbacks;

    private ProgressDialog mVerifyProgress;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_number_verification);
        initViews();


        mVerifyProgress = new ProgressDialog(this);

        phoneNumber = getIntent().getStringExtra("number");

        title.setText(getString(R.string.verify) + " " + phoneNumber);
        msg.setText(getString(R.string.waiting_for_automatically_detect_an_sms_sent_to) + " " + phoneNumber);

        resend.setEnabled(false);
        resend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resendVerificationCode(phoneNumber, mResendToken);
            }
        });

        verify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (code.getText() != null && !code.getText().toString().isEmpty() && mVerificationId != null && !mVerificationId.isEmpty()) {
                    String m_Text = code.getText().toString();

                    mVerifyProgress.setTitle("Verifying");
                    mVerifyProgress.setMessage("Please wait while we Verify your number");
                    mVerifyProgress.setCanceledOnTouchOutside(false);
                    mVerifyProgress.show();

                    PhoneAuthCredential credential = PhoneAuthProvider.getCredential(mVerificationId
                            , m_Text);
                    signInWithPhoneAuthCredential(credential);
                }
            }
        });

        mCallbacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {

            @Override
            public void onVerificationCompleted(PhoneAuthCredential credential) {
                mVerifyProgress.dismiss();
                setResult(RESULT_OK);
                finish();
            }

            @Override
            public void onCodeAutoRetrievalTimeOut(String s) {
                super.onCodeAutoRetrievalTimeOut(s);

            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                // This callback is invoked in an invalid request for verification is made,
                // for instance if the the phone number format is not valid.
                // Log.w(TAG, "onVerificationFailed", e);
                mVerifyProgress.dismiss();
                Toast.makeText(PhoneNumberVerification.this,"Phone Number Verification Failed!",Toast.LENGTH_LONG).show();


            }

            @Override
            public void onCodeSent(String verificationId,
                                   PhoneAuthProvider.ForceResendingToken token) {
                mVerificationId = verificationId;
                mResendToken = token;

                new CountDownTimer(60000, 1000) { // adjust the milli seconds here

                    public void onTick(long millisUntilFinished) {
                        resend.setText(""+String.format("%d sec",
                                TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished) -
                                        TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(millisUntilFinished))));
                    }

                    public void onFinish() {
                        resend.setEnabled(true);
                        resend.setText(getString(R.string.title_resend));
                    }
                }.start();

               mVerifyProgress.dismiss();
            }
        };

        mVerifyProgress.setTitle("Verifying");
        mVerifyProgress.setMessage("Please wait while we Verify your number");
        mVerifyProgress.setCanceledOnTouchOutside(false);
        mVerifyProgress.show();
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                TIMEOUT_DURATION,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks         // OnVerificationStateChangedCallbacks
        );
    }

    private void initViews() {
        resend = findViewById(R.id.resend);
        verify = findViewById(R.id.verify);
        code = findViewById(R.id.code);
        title = findViewById(R.id.ui_verify_number);
        msg = findViewById(R.id.ui_title_sms);
    }

    public void resendVerificationCode(String phoneNumber,
                                       PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                phoneNumber,        // Phone number to verify
                TIMEOUT_DURATION,                 // Timeout duration
                TimeUnit.SECONDS,   // Unit of timeout
                this,               // Activity (for callback binding)
                mCallbacks,         // OnVerificationStateChangedCallbacks
                token);
    }

    private void signInWithPhoneAuthCredential(PhoneAuthCredential credential) {
        FirebaseAuth.getInstance().signInWithCredential(credential)
                .addOnCompleteListener(PhoneNumberVerification.this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        mVerifyProgress.dismiss();
                        if (task.isSuccessful()) {
                            setResult(RESULT_OK);
                            finish();
                        } else {
                            Log.w(TAG, "signInWithCredential:failure", task.getException());
                            Toast.makeText(PhoneNumberVerification.this, R.string.code_not_valid, Toast.LENGTH_LONG).show();

                        }
                    }
                });
    }
}