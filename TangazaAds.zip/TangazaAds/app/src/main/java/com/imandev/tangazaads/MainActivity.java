package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.SnapHelper;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.Layout;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.github.rubensousa.gravitysnaphelper.GravitySnapHelper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.network.ListNetworkRequest;
import com.imandev.tangazaads.adapters.LatestAdAdapter;
import com.imandev.tangazaads.adapters.categoryRecyclerAdapter;
import com.imandev.tangazaads.models.AdPost;
import com.imandev.tangazaads.models.category;

import java.net.InetAddress;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener{

    private FirebaseAuth mAuth;
    private FirebaseFirestore firebaseFirestore;
    private String current_user_id;

    private List<category>cat_list;
    private ShimmerRecyclerView latestRV;
    private List<AdPost> blog_list;
    private categoryRecyclerAdapter categoryRecyclerAdapter;
    private DocumentSnapshot lastVisible;
    private LatestAdAdapter latestAdAdapter;
    private  Boolean isFirstPageFirstload = true;
    private Spinner spinner;
    private String textSpinnner;
    private LinearLayout noInternet;
    private ScrollView mainActivity;

    private LinearLayout addProduct,addService,exploreApp,allView;
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addProduct = findViewById(R.id.product_add);
        addService = findViewById(R.id.service_add);
        exploreApp = findViewById(R.id.explore);
        allView = findViewById(R.id.ViewAll_eve);


        noInternet = findViewById(R.id.lyt_no_connection);
        mainActivity = findViewById(R.id.scrlView_MainActivity);

        findViewById(R.id.bt_retry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               networkCheck();
            }
        });


        latestAdOnCreateView();
        searchCategory();

        allView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent av= new Intent(MainActivity.this,ViewAll.class);
                startActivity(av);
            }
        });

        findViewById(R.id.ViewAll).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent va= new Intent(MainActivity.this,AllCategoriesActivity.class);
                startActivity(va);
            }
        });


        exploreApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent xp= new Intent(MainActivity.this,ExploreActivity.class);
                startActivity(xp);
            }
        });

        addProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent prod = new Intent(MainActivity.this,AddProductAd.class);
                prod.putExtra("post_id","1");
                startActivity(prod);
            }
        });

        addService.setEnabled(false);

        addService.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent prod = new Intent(MainActivity.this,AddServiceAd.class);
                startActivity(prod);
            }
        });




        cat_list = new ArrayList<>();
        ShimmerRecyclerView catRecyclerView = (ShimmerRecyclerView) findViewById(R.id.recyclerView_categories);
        catRecyclerView.showShimmerAdapter();
        categoryRecyclerAdapter = new categoryRecyclerAdapter(cat_list);
        catRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        catRecyclerView.setAdapter(categoryRecyclerAdapter);

        catRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                Boolean reachedBottom = !recyclerView.canScrollVertically(1);

                if (reachedBottom){
                    //loadMorePosts();
                }
            }
        });

        firebaseFirestore = FirebaseFirestore.getInstance();

        Query firstQuery = firebaseFirestore.collection("Categories").orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(3)
                ;

        firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

               // if (isFirstPageFirstload){
               //     lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
              //      cat_list.clear();
             //   }



                if (queryDocumentSnapshots != null) {
                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {




                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String catId = doc.getDocument().getId();

                            category category = doc.getDocument().toObject(category.class).withId(catId);

                            if (isFirstPageFirstload){

                                cat_list.add(category);

                            }else {

                                cat_list.add(0,category);
                            }
                            categoryRecyclerAdapter.notifyDataSetChanged();
                        }
                    }
                    isFirstPageFirstload = false;
                }
            }
        });


        mAuth = FirebaseAuth.getInstance();
        firebaseFirestore = FirebaseFirestore.getInstance();

        if(mAuth.getCurrentUser() != null){
            current_user_id = mAuth.getCurrentUser().getUid();
        }

        //setupCheck();




    }

    private void searchCategory() {

        spinner = findViewById(R.id.register_category);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.business_category,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);


        findViewById(R.id.btnSearch).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

               

                Intent u = new Intent(MainActivity.this,CategoryDetailActivity.class);
                u.putExtra("cat_title",textSpinnner);


                startActivity(u);
            }
        });

    }

    public void latestAdOnCreateView() {


        //initialization
        blog_list = new ArrayList<>();
         ShimmerRecyclerView latestRV = findViewById(R.id.featured_listing);

        latestAdAdapter = new LatestAdAdapter(blog_list);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

        final LinearLayoutManager linearLayoutManager = new LinearLayoutManager
                (this, LinearLayoutManager.HORIZONTAL, false);
        latestRV.setLayoutManager(linearLayoutManager);
        latestRV.setHasFixedSize(true);

        latestRV.setAdapter(latestAdAdapter);

        //SnapHelper
        final SnapHelper snapHelper = new GravitySnapHelper(Gravity.START);
        snapHelper.attachToRecyclerView(latestRV);

        /*
        //add on scroll animation
        latestAdRecycleView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                if (newState == RecyclerView.SCROLL_STATE_IDLE){
                    View view = snapHelper.findSnapView(linearLayoutManager);
                    assert view != null;
                    int pos = linearLayoutManager.getPosition(view);

                    RecyclerView.ViewHolder viewHolder = latestAdRecycleView.findViewHolderForAdapterPosition(pos);

                    assert viewHolder != null;
                    LinearLayout linearParent = viewHolder.itemView.findViewById(R.id.lineaeparent);
                    linearParent.animate().scaleX(1).scaleX(1).setDuration(350).start();

                }else {

                    View view = snapHelper.findSnapView(linearLayoutManager);
                    assert view != null;
                    int pos = linearLayoutManager.getPosition(view);

                    RecyclerView.ViewHolder viewHolder = latestAdRecycleView.findViewHolderForAdapterPosition(pos);

                    assert viewHolder != null;
                    LinearLayout linearParent = viewHolder.itemView.findViewById(R.id.lineaeparent);
                    linearParent.animate().scaleX(0.7f).scaleX(0.7f).setDuration(350).start();

                }
            }

            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
            }
        });

         */

 firebaseFirestore = FirebaseFirestore.getInstance();


            Query firstQuery = firebaseFirestore.collection("Ads Pool")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .limit(5);

            firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
                @Override
                public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                   // if (isFirstPageFirstload){
                     //   lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
                       // blog_list.clear();
                    //}



                    if (queryDocumentSnapshots != null) {
                        for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {

                            if (doc.getType() == DocumentChange.Type.ADDED) {

                                String blogPostId = doc.getDocument().getId();

                                AdPost blogPost = doc.getDocument().toObject(AdPost.class).withId(blogPostId);


                                if (isFirstPageFirstload){

                                    blog_list.add(blogPost);
                                }else {

                                    blog_list.add(0,blogPost);
                                }


                                latestAdAdapter.notifyDataSetChanged();
                            }

                        }

                        isFirstPageFirstload = false;
                    }

                }
            });

        }



    @Override
    protected void onStart() {

        super.onStart();
        networkCheck();

    }

    private void networkCheck() {
        if (!isNetworkConnected() && !isInternetAvailable()) {
            Toast.makeText(MainActivity.this, "Please Connect to The Internet to access content of this app", Toast.LENGTH_LONG).show();
            noInternet.setVisibility(View.VISIBLE);
            mainActivity.setVisibility(View.GONE);

        } else {

            mainActivity.setVisibility(View.VISIBLE);
            noInternet.setVisibility(View.GONE);
        }
    }


    private boolean isNetworkConnected() {
        ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        return cm.getActiveNetworkInfo() != null && cm.getActiveNetworkInfo().isConnected();
    }

    public boolean isInternetAvailable() {
        try {
            InetAddress ipAddr = InetAddress.getByName("google.com");
            //You can replace it with your name
            return !ipAddr.equals("");

        } catch (Exception e) {
            return false;
        }
    }

    private void setupCheck() {

        firebaseFirestore.collection("Users").document(current_user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @SuppressLint("CheckResult")
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                if (task.isSuccessful()){

                    if (task.getResult().exists()){

                        String accountType = task.getResult().getString("account_type");



                        Toast.makeText(MainActivity.this, "Welcome To Tangaza Ads", Toast.LENGTH_SHORT).show();
                    }else {

                        Intent i = new Intent(MainActivity.this,SetupActivity.class);
                        startActivity(i);

                    }

                }else {


                }

            }
        });

    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        textSpinnner = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}