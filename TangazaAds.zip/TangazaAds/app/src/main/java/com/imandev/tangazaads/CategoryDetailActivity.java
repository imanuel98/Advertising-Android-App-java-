package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Build;
import android.os.Bundle;
import android.widget.TextView;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.imandev.tangazaads.adapters.AdvertRecyclerAdapter;
import com.imandev.tangazaads.adapters.categoryRecyclerAdapter;
import com.imandev.tangazaads.models.AdPost;
import com.imandev.tangazaads.models.category;

import java.util.ArrayList;
import java.util.List;

public class CategoryDetailActivity extends AppCompatActivity {

    private List<AdPost> cat_list;
    private AdvertRecyclerAdapter categoryRecyclerAdapter;
    private DocumentSnapshot lastVisible;
    private  Boolean isFirstPageFirstload = true;
    private String cat_title,cat_desc;
    private TextView Title,Desc;
    private SwipeRefreshLayout swipeRefreshLayout;

    private  RecyclerView catRecyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category_detail);

        Title = findViewById(R.id.detailed_title);
        Desc = findViewById(R.id.detailed_desc);

        swipeRefreshLayout = findViewById(R.id.category_refresh);


        cat_title = getIntent().getStringExtra("cat_title");
        Title.setText(cat_title);


        cat_desc = getIntent().getStringExtra("cat_desc");
        Desc.setText(cat_desc);

        cat_list = new ArrayList<>();
        catRecyclerView =  findViewById(R.id.catRv);

        categoryRecyclerAdapter = new AdvertRecyclerAdapter(cat_list);
        catRecyclerView.setLayoutManager(new LinearLayoutManager(CategoryDetailActivity.this));

        catRecyclerView.setAdapter(categoryRecyclerAdapter);

        catRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                Boolean reachedBottom = !recyclerView.canScrollVertically(1);

                if (reachedBottom){
                    //loadMorePosts();
                }
            }
        });

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                cat_list.clear();
                getCatDetails();
            }
        });

        getCatDetails();


    }

    private void getCatDetails() {
        swipeRefreshLayout.setRefreshing(true);



        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();

        Query firstQuery = firebaseFirestore.collection("Ads Pool").orderBy("timestamp", Query.Direction.DESCENDING)
                .whereEqualTo("adtype",cat_title)
                ;

        firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                if (isFirstPageFirstload){
//                    lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
                    cat_list.clear();
                }



                if (queryDocumentSnapshots != null) {
                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {




                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String catId = doc.getDocument().getId();

                            AdPost adPost = doc.getDocument().toObject(AdPost.class).withId(catId);

                            if (isFirstPageFirstload){

                                cat_list.add(adPost);

                            }else {

                                cat_list.add(0,adPost);
                            }
                            categoryRecyclerAdapter.notifyDataSetChanged();
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    }
                    isFirstPageFirstload = false;
                }
            }
        });

    }
}