package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Build;
import android.os.Bundle;

import com.cooltechworks.views.shimmer.ShimmerRecyclerView;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.imandev.tangazaads.adapters.categoryRecyclerAdapter;
import com.imandev.tangazaads.models.category;

import java.util.ArrayList;
import java.util.List;

public class AllCategoriesActivity extends AppCompatActivity {

    private List<category> cat_list;
    private categoryRecyclerAdapter categoryRecyclerAdapter;
    private DocumentSnapshot lastVisible;
    private  Boolean isFirstPageFirstload = true;
    private SwipeRefreshLayout swipeRefreshLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_categories);


        swipeRefreshLayout = findViewById(R.id.category_refresh);
        cat_list = new ArrayList<>();
        ShimmerRecyclerView catRecyclerView = (ShimmerRecyclerView) findViewById(R.id.recyclerView_categories);
        catRecyclerView.showShimmerAdapter();
        categoryRecyclerAdapter = new categoryRecyclerAdapter(cat_list);
        catRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        catRecyclerView.setAdapter(categoryRecyclerAdapter);

        catRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                Boolean reachedBottom = !recyclerView.canScrollVertically(1);

                if (reachedBottom){
                    //loadMorePosts();
                }
            }
        });
        getCategories();

        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                cat_list.clear();
                getCategories();
            }
        });


    }

    private void getCategories() {

        swipeRefreshLayout.setRefreshing(true);
        FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();

        Query firstQuery = firebaseFirestore.collection("Categories").orderBy("timestamp", Query.Direction.DESCENDING)
                //.limit(3)
                ;

        firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                if (isFirstPageFirstload){
                    lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
                    cat_list.clear();
                }



                if (queryDocumentSnapshots != null) {
                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {




                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String catId = doc.getDocument().getId();

                            category category = doc.getDocument().toObject(category.class).withId(catId);

                            if (isFirstPageFirstload){

                                cat_list.add(category);

                            }else {

                                cat_list.add(0,category);
                            }
                            categoryRecyclerAdapter.notifyDataSetChanged();
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    }
                    isFirstPageFirstload = false;
                }
            }
        });

    }
}