package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class SignupActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private EditText name;
    private EditText firstName;
    private EditText lastName;
    DatabaseReference reference;
    private View viewProfessionalFields;
    private View viewCategoryFields;

    private View viewSingleLinePhone;
    private EditText compamyTitle;
    private EditText phone;
    private EditText mail;
    private EditText password;
    private EditText confirmPassword;
    private Spinner categories;

    private Button submit,submitbtn;

    private Button registerSingleUser;
    private Button registerBusiness;

    private ProgressDialog mRegisterProgress;
    private FirebaseAuth mAuth;
    private FirebaseFirestore firebaseFirestore;
    private Spinner spinner;
    private String textSpinnner;
    private TextView sendtoLogin;
    private String image_url,location,about;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initViews();




    }

    private void initViews() {

        name = findViewById(R.id.register_name);
        firstName = findViewById(R.id.register_first_name);
        lastName = findViewById(R.id.register_lastname);
        viewProfessionalFields = findViewById(R.id.register_names);
        viewCategoryFields = findViewById(R.id.register_category_view);
        sendtoLogin = findViewById(R.id.login);
        viewSingleLinePhone = findViewById(R.id.single_line_phone);
        compamyTitle = findViewById(R.id.register_company);
        phone = findViewById(R.id.register_location);
        mail = findViewById(R.id.register_email);
        password = findViewById(R.id.register_password);
        confirmPassword = findViewById(R.id.register_retype_password);
        categories = findViewById(R.id.register_category);
        submit = findViewById(R.id.register_submit);
        submitbtn = findViewById(R.id.register_submitbtn);
        registerSingleUser = findViewById(R.id.register_single_user);
        registerBusiness = findViewById(R.id.register_business);


        mRegisterProgress = new ProgressDialog(this);
        mAuth = FirebaseAuth.getInstance();
        registerBusiness.setSelected(true);
        registerSingleUser.setSelected(false);
        firebaseFirestore = FirebaseFirestore.getInstance();



        image_url = "https://w0.pngwave.com/png/613/636/computer-icons-user-profile-male-avatar-avatar-png-clip-art-thumbnail.png";
        location= "Kenya";
        about = "About";



        spinner = findViewById(R.id.register_category);

        final ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.business_category,
                android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener((AdapterView.OnItemSelectedListener) this);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignUpBusiness();

            }
        });

        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SignupSingleUser();
            }
        });

        registerSingleUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                submitbtn.setVisibility(View.VISIBLE);
                submit.setVisibility(View.GONE);
                registerSingleUser.setSelected(true);
                registerBusiness.setSelected(false);
                viewSingleLinePhone.setVisibility(View.GONE);
                hideShowTypeBasedViews(View.VISIBLE);
                hideCategoryViews(View.GONE);

                compamyTitle.setVisibility(View.GONE);
                registerSingleUser.setBackgroundColor(getResources().getColor(R.color.background));
                registerBusiness.setBackgroundColor(getResources().getColor(R.color.cardview_light_background));
            }
        });
        registerBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                registerSingleUser.setSelected(false);
                registerBusiness.setSelected(true);
                viewSingleLinePhone.setVisibility(View.VISIBLE);
                submit.setVisibility(View.VISIBLE);
                submitbtn.setVisibility(View.GONE);
                registerBusiness.setBackgroundColor(getResources().getColor(R.color.background));
                registerSingleUser.setBackgroundColor(getResources().getColor(R.color.cardview_light_background));

                hideShowTypeBasedViews(View.GONE);
                hideCategoryViews(View.VISIBLE);
                compamyTitle.setVisibility(View.VISIBLE);

            }
        });

        sendtoLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(SignupActivity.this,LoginActivity.class);
                startActivity(login);
            }
        });
    }

    private  void SignUpBusiness(){

        final String email = mail.getText().toString();
        String pass = password.getText().toString();
        String confirm_pass = confirmPassword.getText().toString();
        final String cname = compamyTitle.getText().toString();
        final String phoneNo = phone.getText().toString();
        final String username = name.getText().toString();
        final String category = textSpinnner;
        final String account_type = "1";



        if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass) && !TextUtils.isEmpty(confirm_pass) &&
                !TextUtils.isEmpty(cname) && !TextUtils.isEmpty(phoneNo) && !TextUtils.isEmpty(username)){

            if(pass.equals(confirm_pass)){

                mRegisterProgress.setTitle("Signing Up");
                mRegisterProgress.setMessage("Please wait while we create your Business Account");
                mRegisterProgress.setCanceledOnTouchOutside(false);
                mRegisterProgress.show();

                mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            FirebaseUser firebaseUser = mAuth.getCurrentUser();

                            final String user_id = mAuth.getCurrentUser().getUid();
                            assert firebaseUser != null;
                            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()){

                                        Map<String, String> BusinessUserMap = new HashMap<>();

                                        BusinessUserMap.put("name", username);
                                        BusinessUserMap.put("phone", phoneNo);
                                        BusinessUserMap.put("email", email);
                                        BusinessUserMap.put("company_name", cname);
                                        BusinessUserMap.put("category", category);
                                        BusinessUserMap.put("user_id", user_id);
                                        BusinessUserMap.put("image_url", image_url);
                                        BusinessUserMap.put("location",location);
                                        BusinessUserMap.put("about",about);
                                        firebaseFirestore.collection("Business Users").document(user_id).set(BusinessUserMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                if (task.isSuccessful()){


                                                    Toast.makeText(SignupActivity.this,"Completing",Toast.LENGTH_SHORT).show();

                                                    Map<String, String> BusinessUserMap = new HashMap<>();
                                                    BusinessUserMap.put("name", username);
                                                    BusinessUserMap.put("phone", phoneNo);
                                                    BusinessUserMap.put("email", email);
                                                    BusinessUserMap.put("company_name", cname);
                                                    BusinessUserMap.put("category", category);
                                                    BusinessUserMap.put("user_id", user_id);
                                                    BusinessUserMap.put("image_url", image_url);
                                                    BusinessUserMap.put("location",location);
                                                    BusinessUserMap.put("about",about);
                                                    BusinessUserMap.put("account_type",account_type);


                                                    firebaseFirestore.collection("Users").document(user_id).set(BusinessUserMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {

                                                            if (task.isSuccessful()){

                                                                FirebaseUser firebaseUser = mAuth.getCurrentUser();
                                                                assert firebaseUser != null;
                                                                String userid = firebaseUser.getUid();

                                                                reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

                                                                HashMap<String, String> hashMap = new HashMap<>();
                                                                hashMap.put("id", userid);
                                                                hashMap.put("username", username);
                                                                hashMap.put("phone", phoneNo);
                                                                hashMap.put("status", "offline");
                                                                hashMap.put("search", username.toLowerCase());


                                                                reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        if (task.isSuccessful()){


                                                                            Toast.makeText(SignupActivity.this, "Business Created Successfully " , Toast.LENGTH_LONG ).show();
                                                                            mRegisterProgress.dismiss();
                                                                            Intent mainIntent = new Intent(SignupActivity.this, PhoneNumberVerification.class);
                                                                            mainIntent.putExtra("number", phoneNo);
                                                                            startActivity(mainIntent);

                                                                            finish();
                                                                        }
                                                                    }
                                                                });

                                                                Toast.makeText(SignupActivity.this,"Done",Toast.LENGTH_SHORT).show();

                                                            }else {
                                                                String error = task.getException().getMessage();
                                                                Toast.makeText(SignupActivity.this, "FIRESTORE  Error : " +error, Toast.LENGTH_LONG ).show();
                                                            }

                                                        }
                                                    });


                                                }else {
                                                    String error = task.getException().getMessage();
                                                    Toast.makeText(SignupActivity.this, "FIRESTORE  Error : " +error, Toast.LENGTH_LONG ).show();
                                                }

                                            }
                                        });

                                    }
                                }
                            });

                        } else {

                            String errorMessage = task.getException().getMessage();
                            Toast.makeText(SignupActivity.this, "Error : " + errorMessage, Toast.LENGTH_LONG).show();

                        }
                    }
                });

            } else {

                Toast.makeText(SignupActivity.this, "Confirm Password and Password Field doesn't match.", Toast.LENGTH_LONG).show();

            }
        }else {

            Toast.makeText(SignupActivity.this, "Please Fill in the empty fields first", Toast.LENGTH_LONG).show();
        }

    }


    private void SignupSingleUser(){

        final String email = mail.getText().toString();
         String pass = password.getText().toString();
        String confirm_pass = confirmPassword.getText().toString();
        final String fname = firstName.getText().toString();
        final String lname = lastName.getText().toString();
        final String phoneNo = phone.getText().toString();
        final String username = name.getText().toString();
        final  String account_type = "0";

        if(!TextUtils.isEmpty(email) && !TextUtils.isEmpty(pass) && !TextUtils.isEmpty(confirm_pass) &&
                !TextUtils.isEmpty(fname) && !TextUtils.isEmpty(lname) && !TextUtils.isEmpty(phoneNo) && !TextUtils.isEmpty(username)){

            if(pass.equals(confirm_pass)){


                mRegisterProgress.setTitle("Signing Up");
                mRegisterProgress.setMessage("Please wait while we create your Personal Account");
                mRegisterProgress.setCanceledOnTouchOutside(false);
                mRegisterProgress.show();

                mAuth.createUserWithEmailAndPassword(email, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {

                        if(task.isSuccessful()){

                            FirebaseUser firebaseUser = mAuth.getCurrentUser();

                            final String user_id = mAuth.getCurrentUser().getUid();
                            assert firebaseUser != null;
                            firebaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {

                                    if (task.isSuccessful()){

                                        Map<String, String> regularUserMap = new HashMap<>();

                                        regularUserMap.put("name", username);
                                        regularUserMap.put("phone", phoneNo);
                                        regularUserMap.put("email", email);
                                        regularUserMap.put("first_name", fname);
                                        regularUserMap.put("company_name", username);
                                        regularUserMap.put("last_name", lname);
                                        regularUserMap.put("user_id", user_id);
                                        regularUserMap.put("image_url", image_url);
                                        regularUserMap.put("location",location);
                                        regularUserMap.put("about",about);

                                        firebaseFirestore.collection("Regular Users").document(user_id).set(regularUserMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                if (task.isSuccessful()){

                                                    Map<String, String> regularUserMap = new HashMap<>();

                                                    regularUserMap.put("name", username);
                                                    regularUserMap.put("phone", phoneNo);
                                                    regularUserMap.put("email", email);
                                                    regularUserMap.put("first_name", fname);
                                                    regularUserMap.put("last_name", lname);
                                                    regularUserMap.put("user_id", user_id);
                                                    regularUserMap.put("image_url", image_url);
                                                    regularUserMap.put("location",location);
                                                    regularUserMap.put("about",about);
                                                    regularUserMap.put("account_type",account_type);

                                                    Toast.makeText(SignupActivity.this,"Completing",Toast.LENGTH_SHORT).show();

                                                    firebaseFirestore.collection("Users").document(user_id).set(regularUserMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                        @Override
                                                        public void onComplete(@NonNull Task<Void> task) {

                                                            if (task.isSuccessful()){

                                                                FirebaseUser firebaseUser = mAuth.getCurrentUser();
                                                                assert firebaseUser != null;
                                                                String userid = firebaseUser.getUid();

                                                                reference = FirebaseDatabase.getInstance().getReference("Users").child(userid);

                                                                HashMap<String, String> hashMap = new HashMap<>();
                                                                hashMap.put("id", userid);
                                                                hashMap.put("username", username);
                                                                hashMap.put("status", "offline");
                                                                hashMap.put("search", username.toLowerCase());


                                                                reference.setValue(hashMap).addOnCompleteListener(new OnCompleteListener<Void>() {
                                                                    @Override
                                                                    public void onComplete(@NonNull Task<Void> task) {
                                                                        if (task.isSuccessful()){

                                                                            Toast.makeText(SignupActivity.this, "User Created Successfully " , Toast.LENGTH_LONG ).show();
                                                                            mRegisterProgress.dismiss();
                                                                            Intent mainIntent = new Intent(SignupActivity.this, PhoneNumberVerification.class);
                                                                            mainIntent.putExtra("number", phoneNo);
                                                                            startActivity(mainIntent);

                                                                            finish();
                                                                        }
                                                                    }
                                                                });

                                                                Toast.makeText(SignupActivity.this,"Done",Toast.LENGTH_SHORT).show();

                                                            }else {
                                                                String error = task.getException().getMessage();
                                                                Toast.makeText(SignupActivity.this, "FIRESTORE  Error : " +error, Toast.LENGTH_LONG ).show();
                                                            }

                                                        }
                                                    });


                                                }else {
                                                    String error = task.getException().getMessage();
                                                    Toast.makeText(SignupActivity.this, "FIRESTORE  Error : " +error, Toast.LENGTH_LONG ).show();
                                                }
                                            }
                                        });
                                    }
                                }
                            });

                        } else {

                            String errorMessage = task.getException().getMessage();
                            Toast.makeText(SignupActivity.this, "Error : " + errorMessage, Toast.LENGTH_LONG).show();
                        }
                    }
                });

            } else {

                Toast.makeText(SignupActivity.this, "Confirm Password and Password Field doesn't match.", Toast.LENGTH_LONG).show();

            }
        }else {

            Toast.makeText(SignupActivity.this, "Please Fill in the empty fields first", Toast.LENGTH_LONG).show();
        }
    }


    private void hideShowTypeBasedViews(int visibility) {
        viewProfessionalFields.setVisibility(visibility);
        firstName.setVisibility(visibility);
        lastName.setVisibility(visibility);

    }


    private void hideCategoryViews(int visibility) {
        viewCategoryFields.setVisibility(visibility);
    }


    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {

        textSpinnner = adapterView.getItemAtPosition(i).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}