package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.theartofdev.edmodo.cropper.CropImage;
import com.theartofdev.edmodo.cropper.CropImageView;

import java.util.HashMap;
import java.util.Map;

public class SetupActivity extends AppCompatActivity {

    private EditText name;
    private EditText firstName;
    private EditText lastName;
    DatabaseReference reference;
    private View viewProfessionalFields;
    private View viewCategoryFields;
    private StorageReference storageReference;
    private Boolean isChanged = false;

    private View viewSingleLinePhone;
    private EditText compamyTitle;


    private EditText locationET;
    private EditText aboutET;
    private Spinner categories;

    private Button submit,submitbtn;

    private Button registerSingleUser;
    private Button registerBusiness;

    private ProgressDialog mSetupProgress;
    private FirebaseAuth mAuth;
    private FirebaseFirestore firebaseFirestore;
    private Spinner spinner;
    private String textSpinnner;
    private TextView sendtoLogin;
    private String current_user_id;

    private Uri mainImageURI = null;
    private ImageView setupImage;

    private String phone,category,email,acctype,company;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setup);

        initViews();
        checkAccountType();

        if(mAuth.getCurrentUser() != null){
            current_user_id = mAuth.getCurrentUser().getUid();
        }


        setupImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){

                    if(ContextCompat.checkSelfPermission(SetupActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED){

                        Toast.makeText(SetupActivity.this, "Permission Denied", Toast.LENGTH_LONG).show();
                        ActivityCompat.requestPermissions(SetupActivity.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1);

                    } else {

                        BringImagePicker();

                    }

                } else {

                    BringImagePicker();

                }

            }

        });


    }

    private void checkAccountType() {

        mSetupProgress.setMessage("Populating Profile....");
        mSetupProgress.setCanceledOnTouchOutside(false);
        mSetupProgress.show();


        current_user_id = mAuth.getCurrentUser().getUid();

        firebaseFirestore = FirebaseFirestore.getInstance();

        firebaseFirestore.collection("Users").document(current_user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @SuppressLint("CheckResult")
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                if (task.isSuccessful()){

                    if (task.getResult().exists()){

                        mSetupProgress.setMessage("Retrieving Profile....");
                        mSetupProgress.setCanceledOnTouchOutside(false);
                        mSetupProgress.show();

                        String uname = task.getResult().getString("name");
                        String aboutUser = task.getResult().getString("about");
                        String image = task.getResult().getString("image_url");
                        String locationUser = task.getResult().getString("location");


                         phone = task.getResult().getString("phone");
                         category = task.getResult().getString("category");
                          company= task.getResult().getString("company_name");
                          email = task.getResult().getString("email");
                         acctype = task.getResult().getString("account_type");

                        mainImageURI = Uri.parse(image);
                        name.setText(uname);
                        locationET.setText(locationUser);
                        aboutET.setText(aboutUser);


                        RequestOptions placeholderRequest = new RequestOptions();
                        placeholderRequest.placeholder(R.drawable.default_image);


                        Glide.with(SetupActivity.this).setDefaultRequestOptions(placeholderRequest).load(image).into(setupImage);


                    }
                }

                mSetupProgress.dismiss();
            }
        });


        submitbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String user_name = name.getText().toString();
                final String user_location = locationET.getText().toString();
                final String first_name = firstName.getText().toString();
                final String last_name = lastName.getText().toString();
                final String user_about = aboutET.getText().toString();



                if (!TextUtils.isEmpty(user_name) && !TextUtils.isEmpty(user_location) && !TextUtils.isEmpty(user_about) && mainImageURI != null ) {
                    //setupProgress.setVisibility(View.VISIBLE);




                    mSetupProgress.setTitle("Updating  Account");
                    mSetupProgress.setMessage("Please wait while we Update your Account");
                    mSetupProgress.setCanceledOnTouchOutside(false);
                    mSetupProgress.show();

                    if (isChanged) {

                        final String user_id = mAuth.getCurrentUser().getUid();
                        storageReference = FirebaseStorage.getInstance().getReference();

                        final StorageReference image_path = storageReference.child("profile images").child(user_id + ".jpg");

                        Task uploadTask = image_path.putFile(mainImageURI);

                        uploadTask.continueWithTask(new Continuation() {
                            @Override
                            public Object then(@NonNull Task task) throws Exception {

                                if (!task.isSuccessful()) {

                                    throw task.getException();

                                }
                                return image_path.getDownloadUrl();
                            }
                        })
                                .addOnCompleteListener(new OnCompleteListener() {
                                    @Override
                                    public void onComplete(@NonNull Task task) {

                                        if (task.isSuccessful()) {

                                            storeFirestore(task, user_name, user_location,user_about);

                                        } else {

                                            String error = task.getException().getMessage();
                                            Toast.makeText(SetupActivity.this, "IMAGE    Error : " + error, Toast.LENGTH_LONG).show();

                                            //setupProgress.setVisibility(View.INVISIBLE);
                                            mSetupProgress.dismiss();

                                        }
                                    }
                                });




                    } else {


                        storeFirestore(null, user_name, user_location,user_about);


                    }



                }
            }

        });

    }



    private void BringImagePicker() {

        CropImage.activity()
                .setGuidelines(CropImageView.Guidelines.ON)
                .setAspectRatio(1, 1)
                .start(SetupActivity.this);

    }

    private void storeFirestore(Task task, String user_name, String user_location, String user_about) {
        final Uri download_uri;

        if (task != null){

            download_uri = (Uri) task.getResult();

        }else{

            download_uri = mainImageURI;

        }

        Map<String, String> regularUserMap = new HashMap<>();

        regularUserMap.put("name", user_name);
        regularUserMap.put("user_id", current_user_id);
        regularUserMap.put("image_url", download_uri.toString());
        regularUserMap.put("location",user_location);
        regularUserMap.put("about",user_about);

        regularUserMap.put("phone",phone);
        regularUserMap.put("category",category);
        regularUserMap.put("company_name",company);
        regularUserMap.put("email",email);
        regularUserMap.put("account_type",acctype);





        firebaseFirestore.collection("Users").document(current_user_id).set(regularUserMap).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                if (task.isSuccessful()){



                    Toast.makeText(SetupActivity.this, "The User Settings are Sucesfully Updated " , Toast.LENGTH_LONG ).show();
                    Intent mainIntent = new Intent(SetupActivity.this, ExploreActivity.class);
                    startActivity(mainIntent);
                    finish();

                }else {

                    String error = task.getException().getMessage();
                    Toast.makeText(SetupActivity.this, "FIRESTORE  Error : " +error, Toast.LENGTH_LONG ).show();


                }

               mSetupProgress.dismiss();

            }
        });

    }


    private void initViews() {

        name = findViewById(R.id.register_name);
        firstName = findViewById(R.id.register_first_name);
        lastName = findViewById(R.id.register_lastname);
        viewProfessionalFields = findViewById(R.id.register_names);
        viewCategoryFields = findViewById(R.id.register_category_view);
        sendtoLogin = findViewById(R.id.login);
        viewSingleLinePhone = findViewById(R.id.single_line_phone);
        compamyTitle = findViewById(R.id.register_company);
        locationET = findViewById(R.id.register_location);
        aboutET = findViewById(R.id.register_about);
        categories = findViewById(R.id.register_category);
        submitbtn = findViewById(R.id.register_submitbtn);
        registerSingleUser = findViewById(R.id.register_single_user);
        registerBusiness = findViewById(R.id.register_business);
        firebaseFirestore =FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        setupImage = findViewById(R.id.setupImage);
        storageReference = FirebaseStorage.getInstance().getReference();

        mSetupProgress = new ProgressDialog(this);



    }

    private void hideShowTypeBasedViews(int visibility) {
        viewProfessionalFields.setVisibility(visibility);
        firstName.setVisibility(visibility);
        lastName.setVisibility(visibility);

    }


    private void hideCategoryViews(int visibility) {
        viewCategoryFields.setVisibility(visibility);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            CropImage.ActivityResult result = CropImage.getActivityResult(data);
            if (resultCode == RESULT_OK) {

                mainImageURI = result.getUri();
                setupImage.setImageURI(mainImageURI);

                isChanged = true;

            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {

                Exception error = result.getError();

            }
        }

    }
}