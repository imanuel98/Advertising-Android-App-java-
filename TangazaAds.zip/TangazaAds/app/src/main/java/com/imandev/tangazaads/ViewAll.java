package com.imandev.tangazaads;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.os.Bundle;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;
import com.imandev.tangazaads.adapters.AdvertRecyclerAdapter;
import com.imandev.tangazaads.models.AdPost;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class ViewAll extends AppCompatActivity {

    private RecyclerView blog_list_view;
    private List<AdPost> blog_list;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;
    private AdvertRecyclerAdapter advertRecyclerAdapter;
    private DocumentSnapshot lastVisible;
    private  Boolean isFirstPageFirstload = true;
    private SwipeRefreshLayout swipeRefreshLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_all);

        blog_list = new ArrayList<>();
        blog_list_view = findViewById(R.id.blog_list_view);

        advertRecyclerAdapter = new AdvertRecyclerAdapter(blog_list);
        firebaseAuth = FirebaseAuth.getInstance();

        blog_list_view.setLayoutManager(new LinearLayoutManager(ViewAll.this));
        blog_list_view.setAdapter(advertRecyclerAdapter);

        swipeRefreshLayout = findViewById(R.id.viewall_refresh);
        firebaseFirestore = FirebaseFirestore.getInstance();


        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                blog_list.clear();
                getPosts();
            }
        });

        getPosts();

    }

    private void getPosts() {
        swipeRefreshLayout.setRefreshing(true);

        blog_list_view.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);

                Boolean reachedBottom = !recyclerView.canScrollVertically(1);

                if (reachedBottom){
                    loadMorePosts();
                }
            }
        });
        Query firstQuery = firebaseFirestore.collection("Ads Pool").orderBy("timestamp", Query.Direction.DESCENDING).limit(3);

        firstQuery.addSnapshotListener ( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                if (isFirstPageFirstload){
                    lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);
                    blog_list.clear();
                }

                if (queryDocumentSnapshots != null) {
                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {




                        if (doc.getType() == DocumentChange.Type.ADDED) {

                            String blogPostId = doc.getDocument().getId();

                            AdPost blogPost = doc.getDocument().toObject(AdPost.class).withId(blogPostId);

                            if (isFirstPageFirstload){

                                blog_list.add(blogPost);
                            }else {

                                blog_list.add(0,blogPost);
                            }
                            advertRecyclerAdapter.notifyDataSetChanged();
                            swipeRefreshLayout.setRefreshing(false);
                        }
                    }
                    isFirstPageFirstload = false;
                }
            }
        });
    }

    public void loadMorePosts(){
        //swipeRefreshLayout.setRefreshing(true);
        Query nextQuery = firebaseFirestore.collection("Ads Pool")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .startAfter(lastVisible)
                .limit(3);

        nextQuery.addSnapshotListener(ViewAll.this, new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                assert queryDocumentSnapshots != null;
                if (!queryDocumentSnapshots.isEmpty()) {

                    lastVisible = queryDocumentSnapshots.getDocuments().get(queryDocumentSnapshots.size() - 1);

                    for (DocumentChange doc : queryDocumentSnapshots.getDocumentChanges()) {

                        if (doc.getType() == DocumentChange.Type.ADDED) {
                            String blogPostId = doc.getDocument().getId();
                            AdPost blogPost = doc.getDocument().toObject(AdPost.class).withId(blogPostId);
                            blog_list.add(blogPost);
                            advertRecyclerAdapter.notifyDataSetChanged();
                            swipeRefreshLayout.setRefreshing(false);
                        }

                    }
                }

            }
        });

    }
}