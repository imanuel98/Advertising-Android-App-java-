package com.imandev.tangazaads;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;

import javax.annotation.Nullable;

public class StatisticsActivity extends AppCompatActivity {

    private String adPostId,adImageUri,adTitle;
    private ImageView adPic;
    private TextView advertTitle;

    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;

    private TextView textViewThumbs;
    private TextView textViewViews;
    private TextView textViewComment;

    private TextView textViewAdReach;
    private TextView textViewAdReaction;


    private float views;
    private float reaction;
    private float count;
    private float usersNo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);


        Toolbar setupToolbar = findViewById(R.id.stat_toolbar);
        setSupportActionBar(setupToolbar);
        getSupportActionBar().setTitle("Advert Statistics");

//initialization
        adPic = findViewById(R.id.ad_pic);
        advertTitle = findViewById(R.id.ad_title);
        textViewAdReach = findViewById(R.id.adReachTV);
        textViewAdReaction = findViewById(R.id.adReactionTV);


        adPostId = getIntent().getStringExtra("post_id");
        adImageUri = getIntent().getStringExtra("image_url");
        adTitle = getIntent().getStringExtra("ad_title");



        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();

        //view casting
        advertTitle.setText(adTitle);
        RequestOptions requestOptions = new RequestOptions();
        requestOptions.placeholder(R.drawable.placeholder);


        Glide.with(this)
                .applyDefaultRequestOptions(requestOptions)
                .load(adImageUri).into(adPic);

        //Get Thumbs count
        firebaseFirestore.collection("Ads Pool/" + adPostId + "/Likes").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {


                if (queryDocumentSnapshots != null) {
                    if (!queryDocumentSnapshots.isEmpty()){

                        count = queryDocumentSnapshots.size();

                        updateLikesCount((int) count);

                    }else {
                        updateLikesCount(0);
                    }
                }

            }
        });

        //Get views Count
        firebaseFirestore.collection("Ads Pool/" + adPostId+ "/View").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {


                if (queryDocumentSnapshots != null) {
                    if (!queryDocumentSnapshots.isEmpty()){

                        views = queryDocumentSnapshots.size();

                        updateViewsCount((int) views);

                    }else{

                        updateViewsCount(0);

                    }
                }

            }
        });

        //Get comments Count
        firebaseFirestore.collection("Ads Pool/" + adPostId + "/Comments").addSnapshotListener( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(QuerySnapshot documentSnapshots, FirebaseFirestoreException e) {
                if (e == null) {
                    if (!documentSnapshots.isEmpty()) {

                        reaction = documentSnapshots.size();

                        updateCommentsCount((int) reaction);

                    }else {
                        updateCommentsCount(0);
                    }

                }

            }
        });

        //Get User Count
        firebaseFirestore.collection("Users").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                if (queryDocumentSnapshots != null) {

                    usersNo = queryDocumentSnapshots.size();



                    textViewAdReach.setText((views / usersNo) * 100 + "%");

                    textViewAdReaction.setText((count / usersNo) * 100 + " %");

                }


            }
        });


    }

    public void updateLikesCount(int count){
        textViewThumbs = findViewById(R.id.thumbsTV);
        textViewThumbs.setText(count + " ");
    }

    public void updateCommentsCount(int reaction){
        textViewComment = findViewById(R.id.commentTV);
        textViewComment.setText(reaction + " ");

    }
    public void updateViewsCount(int views){
        textViewViews = findViewById(R.id.viewsTV);
        textViewViews.setText(views + " ");
    }


}
