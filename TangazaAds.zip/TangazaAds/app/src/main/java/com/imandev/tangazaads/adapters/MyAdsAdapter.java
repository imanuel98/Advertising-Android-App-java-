package com.imandev.tangazaads.adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.QuerySnapshot;
import com.imandev.tangazaads.AdDetailActivity;
import com.imandev.tangazaads.AddProductAd;
import com.imandev.tangazaads.CommentsActivity;
import com.imandev.tangazaads.R;
import com.imandev.tangazaads.StatisticsActivity;
import com.imandev.tangazaads.models.AdPost;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Nullable;

import de.hdodenhof.circleimageview.CircleImageView;

public class MyAdsAdapter extends RecyclerView.Adapter<MyAdsAdapter.viewHolder> {

    public List<AdPost> ad_list;
    public Context mcontext;
    private FirebaseFirestore firebaseFirestore;
    private FirebaseAuth firebaseAuth;
    private String postId;


    public MyAdsAdapter (List<AdPost> ad_list){


        this.ad_list = ad_list;

    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_my_ads, parent, false);

        firebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth = FirebaseAuth.getInstance();
        mcontext = parent.getContext();
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final viewHolder holder, final int position) {

        holder.setIsRecyclable(false);

        postId = ad_list.get(position).BlogPostId;

        final String currentUserId = firebaseAuth.getCurrentUser().getUid();

        final String desc_data = ad_list.get(position).getDesc();
        holder.setDescText(desc_data);

        final String adDetail = ad_list.get(position).getDetails();

        final String adContact = ad_list.get(position).getContact();

        final String adLocation = ad_list.get(position).getLocation();

        final String adType = ad_list.get(position).getAdtype();




        final String user_id = ad_list.get(position).getUser_id();



        final String image_url = ad_list.get(position).getImage_url();
        final String thumbUri = ad_list.get(position).getImage_thumb();
        holder.setAdImage(image_url, thumbUri);


        //hide users manipulation

        if (currentUserId.equals(user_id)){
            holder.statsBtn.setVisibility(View.VISIBLE);
            holder.deleteBtn.setVisibility(View.VISIBLE);
            holder.editBtn.setVisibility(View.VISIBLE);
        }


        holder.statsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent statistics= new Intent(mcontext, StatisticsActivity.class);
                statistics.putExtra("post_id", postId);
                statistics.putExtra("image_url", image_url);
                statistics.putExtra("ad_title", desc_data);
                mcontext.startActivity(statistics);
            }
        });

        holder.editBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(mcontext, AddProductAd.class);
                i.putExtra("post_id",postId);
                mcontext.startActivity(i);
            }
        });

        holder.deleteBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deleteBuildDialog(mcontext, position).show();


            }
        });

        holder.adImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                //views
                firebaseFirestore.collection("Ads Pool/" + postId + "/View").document(currentUserId).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {


                                if (!task.getResult().exists()){

                                    Map<String, Object>viewsMap = new HashMap<>();
                                    viewsMap.put("timestamp", FieldValue.serverTimestamp());
                                    firebaseFirestore.collection("Ads Pool/" + postId + "/View").document(currentUserId).set(viewsMap);

                                }else {

                                }

                            }
                        });



                Intent intent = new Intent(mcontext, AdDetailActivity.class);
                intent.putExtra("image_url", image_url);
                //intent.putExtra("thumb_url", thumbUri );
                intent.putExtra("post_id", postId);
                intent.putExtra("desc_text", desc_data);
                intent.putExtra("ad_detail", adDetail);
                intent.putExtra("ad_contact", adContact);
                intent.putExtra("ad_location", adLocation);
                intent.putExtra("ad_type", adType);
                intent.putExtra("user_id", user_id);

                mcontext.startActivity(intent);


            }
        });



        //User Data retrieval
        firebaseFirestore.collection("Users").document(user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                if (task.isSuccessful()){

                    String userName = task.getResult().getString("name");
                    String userImage = task.getResult().getString("image_url");
                    holder.setUserData(userName, userImage);


                }else{
                    //Firebase Exception


                }



            }
        });



        long millisecond= ad_list.get(position).getTimestamp().getTime();
        String dateString = DateFormat.format("EEE, MMM d, 'at' h:mm a", new Date(millisecond)).toString();
        holder.setTime(dateString);
        //Date Format
        ///"EEE, MMM d, '' yy" -- Wed, Jul 4, '01
        ///"h:mm a" -- 12:08 PM
        //"dd/MM/yyyy 'at' hh:mm:ss"

        //Get Thumbs count
        firebaseFirestore.collection("Ads Pool/" + postId + "/Likes").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {


                if (queryDocumentSnapshots != null) {
                    if (!queryDocumentSnapshots.isEmpty()){

                        int count = queryDocumentSnapshots.size();
                        holder.updateLikesCount(count);
                    }else{

                        holder.updateLikesCount(0);

                    }
                }

            }
        });

        //Get Views Count
        firebaseFirestore.collection("Ads Pool/" + postId + "/View").addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {


                if (queryDocumentSnapshots != null) {
                    if (!queryDocumentSnapshots.isEmpty()){

                        int views = queryDocumentSnapshots.size();
                        holder.updateViewsCount(views);
                    }else{

                        holder.updateViewsCount(0);

                    }
                }

            }
        });

        //Get Thumbs
        firebaseFirestore.collection("Ads Pool/" + postId + "/Likes").document(currentUserId)
                .addSnapshotListener(new EventListener<DocumentSnapshot>() {
                    @Override
                    public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException e) {

                        if (documentSnapshot != null) {
                            if (documentSnapshot.exists()){

                                holder.blogLikeBtn.setImageDrawable(mcontext.getDrawable(R.mipmap.thumb_icon_on));

                            }else{
                                holder.blogLikeBtn.setImageDrawable(mcontext.getDrawable(R.mipmap.thumb_icon_off));
                            }
                        }

                    }
                });


        //Thumbs feature

        holder.blogLikeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                firebaseFirestore.collection("Ads Pool/" + postId + "/Likes").document(currentUserId).get()
                        .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                            @Override
                            public void onComplete(@NonNull Task<DocumentSnapshot> task) {


                                if (!task.getResult().exists()){

                                    Map<String, Object>likesMap = new HashMap<>();
                                    likesMap.put("timestamp", FieldValue.serverTimestamp());
                                    firebaseFirestore.collection("Ads Pool/" + postId + "/Likes").document(currentUserId).set(likesMap);

                                }else {

                                    firebaseFirestore.collection("Ads Pool/" + postId + "/Likes").document(currentUserId).delete();
                                }

                            }
                        });


            }
        });


        holder.blogCommentBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent commentIntent = new Intent(mcontext, CommentsActivity.class);
                commentIntent.putExtra("blog_post_id", postId);
                commentIntent.putExtra("image_url", image_url);
                mcontext.startActivity(commentIntent);

            }
        });

        //Get Comments Count
        firebaseFirestore.collection("Ads Pool/" + postId + "/Comments").addSnapshotListener( new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(QuerySnapshot documentSnapshots, FirebaseFirestoreException e) {
                if (e == null) {
                    if (!documentSnapshots.isEmpty()) {

                        int reaction = documentSnapshots.size();

                        holder.updateCommentsCount(reaction);

                    } else {

                        holder.updateCommentsCount(0);

                    }

                }

            }
        });

        firebaseFirestore.collection("Business Users").document(user_id).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
            @Override
            public void onComplete(@NonNull Task<DocumentSnapshot> task) {

                if (task.isSuccessful()) {

                    if (task.getResult().exists()) {

                        holder.verifiedIcon.setVisibility(View.VISIBLE);

                    }

                } else {
                    String errorMessage = task.getException().getMessage();
                    Toast.makeText(mcontext, "Error : " + errorMessage, Toast.LENGTH_LONG).show();
                }

            }
        });

    }




    private AlertDialog.Builder deleteBuildDialog(final Context mcontext, final int position) {

        androidx.appcompat.app.AlertDialog.Builder builder = new AlertDialog.Builder(mcontext);
        builder.setTitle("Confirm Delete");
        builder.setMessage("Do you want to DELETE this advert?");
        builder.setCancelable(true);

        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                firebaseFirestore.collection("Ads Pool")
                        .document(postId).delete()
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void aVoid) {

                                ad_list.remove(position);
                                //ad_list.clear();





                            }
                        });

            }
        });

        builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(mcontext, " Keep Advertising" , Toast.LENGTH_SHORT).show();
            }
        });

        return builder;
    }

    @Override
    public int getItemCount() {
        return ad_list.size() ;
    }

    public class viewHolder extends RecyclerView.ViewHolder{

        private View mView;
        private ImageView adImageView;
        private TextView descView;
        private TextView adDate;
        private TextView adUserName;
        private CircleImageView adUserImage;
        private ImageView blogLikeBtn;
        private TextView blogLikeCount;
        private TextView blogCommentCount;
        private TextView blogViewCount;
        private ImageView blogCommentBtn;
        private TextView latestAdType;
        private ImageView statsBtn;
        private ImageView deleteBtn,editBtn;
        private ImageView verifiedIcon;



        public viewHolder(@NonNull View itemView) {
            super(itemView);
            mView = itemView;

            blogLikeBtn = mView.findViewById(R.id.blog_like_btn);
            blogCommentBtn = mView.findViewById(R.id.blog_comment_icon);
            statsBtn = mView.findViewById(R.id.statistics);
            deleteBtn = mView.findViewById(R.id.imageView2);
            verifiedIcon = mView.findViewById(R.id.verifiedIcon);
            editBtn =mView.findViewById(R.id.edit);

        }

        public void setDescText( String descText){

            descView = mView.findViewById(R.id.blog_desc);
            descView.setText(descText);


        }

        @SuppressLint("CheckResult")
        public void setAdImage(String downloadUri, String thumbUri){

            adImageView = mView.findViewById(R.id.blog_image);

            RequestOptions requestOptions = new RequestOptions();
            requestOptions.placeholder(R.drawable.placeholder);


            //Glide.with(latContext).applyDefaultRequestOptions(requestOptions).load(downloadUri).into(adImageView);

            Glide.with(mcontext)

                    .applyDefaultRequestOptions(requestOptions)

                    .load(downloadUri).thumbnail(
                    Glide.with(mcontext).load(thumbUri)
                    //.placeholder(R.drawable.image_placeholder)

            ).into(adImageView);



        }


        public void setTime(String date){

            adDate = mView.findViewById(R.id.blog_date);
            adDate.setText(date);

        }

        public void setUserData(String name, String image){

            adUserName = mView.findViewById(R.id.blog_user_name);
            adUserImage = mView.findViewById(R.id.blog_user_image);


            adUserName.setText(name);

            RequestOptions placeholderOption = new RequestOptions();
            placeholderOption.placeholder(R.drawable.profile_placeholder);

            Glide.with(mcontext)
                    .applyDefaultRequestOptions(placeholderOption)

                    .load(image)
                    // .placeholder(R.drawable.profile_placeholder)
                    .centerCrop()
                    .into(adUserImage);



        }

        public void updateLikesCount(int count){


            blogLikeCount = mView.findViewById(R.id.blog_like_count);
            blogLikeCount.setText(count + " ");
        }
        public void updateCommentsCount(int reaction){

            blogCommentCount = mView.findViewById(R.id.blog_comment_count);
            blogCommentCount.setText(reaction + " ");

        }
        public void updateViewsCount(int views){
            blogViewCount = mView.findViewById(R.id.blog_view_count);
            blogViewCount.setText(views + " ");
        }



    }
}
